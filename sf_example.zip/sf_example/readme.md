git config --global user.email "jmnotteghem@outlook.fr"
git config --global user.name "JM Notteghem"


DATABASE_URL=mysql://root@php-sf:3306/monapp?serverVersion=8.0


wget https://get.symfony.com/cli/installer -O - | bash
mv /root/.symfony/bin/symfony /usr/local/bin/symfony
cd home
symfony new --full NOMDUPROJET


chmod -R 770 src/ config/
symfony serve --port 80